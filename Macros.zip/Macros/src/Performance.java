
public class Performance {
	private int lowProtein;
	private int highProtein;
	private int carbs;
	private int fats;
	private int bodyweight;
	private String user;
	
	private Performance(String user, int bodyweight){
		this.user = user;
		this.bodyweight = bodyweight;
		this.lowProtein = (int)(0.75 * this.bodyweight);
		this.highProtein = this.bodyweight;
		this.fats = (int)(this.bodyweight * 0.4);
		this.carbs = this.bodyweight * 2;
	}
	
	public String toString(){
		String info = "";
		info += "Name: " + this.user + "\n";
		info += "Bodyweight: " + this.bodyweight + "lbs\n";
		info += "Protein: " + this.lowProtein + "-" + this.highProtein + "g\n";
		info += "Fats: " + this.fats + "g\n";
		info += "Carbohydrates: " + this.carbs + "g\n";
		return info;
	}
	
	private void macrosToCal(){
		int p = this.highProtein * 4;
		System.out.println("Protein: " + this.highProtein + " * 4 = " + p + " Calories");
		int f = this.fats * 9;
		System.out.println("Fats: " + this.fats + " * 9 = " + f + " Calories");
		int c = this.carbs * 4;
		System.out.println("Carbohydrates: " + this.carbs + " * 9 = " + c + " Calories");
		int total = p + c + f;
		System.out.println("Total: " + total + " Calories");
	}
	
	public static void macroCal(){
		System.out.println("1g Protein = 4 Calories");
		System.out.println("1g Fat = 9 Calories");
		System.out.println("1g Carb = 4 Calories");
	}
	
	
	public static void main(String [] args){
		Performance calvin = new Performance("Calvin", 130);
		System.out.println(calvin);
		calvin.macrosToCal();
		
		
		
	}
}
